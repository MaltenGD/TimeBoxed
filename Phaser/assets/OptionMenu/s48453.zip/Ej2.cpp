#include <iostream>
#include <string>
#include <vector>
#include <exception>
#include <algorithm>

class horas {
    
private:
    int _segundo, _minuto, _hora;

public:
    horas(int hora, int minuto, int segundo)
    {
        if (segundo >= 0 && segundo <= 59 && minuto >= 0 && minuto <= 59 && hora >= 0 && hora <= 23)
        {
            _segundo = segundo;
            _minuto = minuto;
            _hora = hora;
        }
        else {
            throw "ERROR\n"; 
        } 
    }
    
    horas() 
    {
        _segundo = _minuto = _hora = 0;
    }
    
    ~horas() {} 

    int getHora() const { return _hora; }
    int getMinuto() const { return _minuto; }
    int getSegundo() const { return _segundo; }
        
    friend std::istream& operator>>(std::istream& stream, horas &hora);

    std::ostream& operator<<(std::ostream& stream) const{
        // Hora
        if (getHora() < 10) stream << '0';
        stream << getHora();
        stream << ":";
        // Minuto
        if (getMinuto() < 10) stream << '0';
        stream << getMinuto();
        stream << ":";
        // Segundo
        if (getSegundo() < 10) stream << '0';
        stream << getSegundo();
        return stream;
    }

    std::string toString() const
    {
        std::string res;
        // Hora
        if (getHora() < 10) res += '0';
        res += std::to_string(getHora());
        res += ":";
        // Minuto
        if (getMinuto() < 10) res += '0';
        res += std::to_string(getMinuto());
        res += ":";
        // Segundo
        if (getSegundo() < 10) res += '0';
        res += std::to_string(getSegundo());
        return res;
    }

    bool operator==(const horas& other) const
    {
        return getHora() == other.getHora() && getMinuto() == other.getMinuto() && getSegundo() == other.getSegundo();
    }

    bool operator!=(const horas& other) const
    {
        return !(*this == other);
    }

    bool operator<(const horas& other) const{
        if (getHora() != other.getHora()) 
            return getHora() < other.getHora();

        if (getMinuto() != other.getMinuto())
            return getMinuto() < other.getMinuto();
        
        return getSegundo() < other.getSegundo();
    }

    bool operator>(const horas& other) const{
        return other < *this;
    }

};

std::istream& operator>>(std::istream& stream, horas& hora)
{
    int h, m, s;
    char sep1, sep2; 

    if (!(stream >> h >> sep1 >> m >> sep2 >> s)) {
        return stream;
    }
    
    horas temp(h, m, s); 

    hora._hora = temp.getHora(); 
    hora._minuto = temp.getMinuto(); 
    hora._segundo = temp.getSegundo(); 
    
    return stream;
}

bool ComparaHorasPunteros(const horas* h1, const horas* h2) {
    return *h1 < *h2;
}

std::string CalculaHorario(const std::vector<horas*>& HorariosTrenes, const horas& hora)
{
    auto it = std::lower_bound(
        HorariosTrenes.begin(), 
        HorariosTrenes.end(), 
        &hora,                  
        ComparaHorasPunteros    
    );

    if (it != HorariosTrenes.end()) {
        return (*it)->toString() + "\n"; 
    } else {
        return "NO\n"; 
    }
}

std::string resuelveCaso(int NumTrenes, int NumComprobaciones)
{
    std::string result;
    std::vector<horas*> HorariosTrenes(NumTrenes); 

    for (int i = 0; i < NumTrenes; ++i)
    {
        horas* nuevaHora = new horas(); 
        std::cin >> *nuevaHora; 
        HorariosTrenes[i] = nuevaHora;
    }
    
    for (int i = 0; i < NumComprobaciones; ++i)
    {
        try{
            horas hora;
            std::cin >> hora; 
            
            result += CalculaHorario(HorariosTrenes, hora);
        }
        catch(const char* e){
            result += e; 
        }
    }

    result += "---\n";

    for (horas* horaPtr : HorariosTrenes) {
        delete horaPtr;
    }
    
    return result;
}


int main()
{
    int NumTrenes(0);
    int NumComprobaciones(0);
    
    while (std::cin >> NumTrenes >> NumComprobaciones && (NumTrenes != 0 || NumComprobaciones != 0))
    {
        if (NumTrenes == 0) continue;

        std::string resultado = resuelveCaso(NumTrenes, NumComprobaciones);
        std::cout << resultado;
    }
    
    return 0;
}